<?php
require_once __DIR__ . '/includes/auth.php';
logoutUser();
header('Location: ../front-end/index.php');
exit;

// logout
