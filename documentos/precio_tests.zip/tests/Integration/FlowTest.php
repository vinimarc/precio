
<?php
use PHPUnit\Framework\TestCase;

class FlowTest extends TestCase {

    public function test_login_structure() {
        $_POST['email'] = 'test@test.com';
        $_POST['password'] = '123456';

        $this->assertNotEmpty($_POST['email']);
        $this->assertNotEmpty($_POST['password']);
    }

    public function test_search_logic() {
        $query = "iphone";
        $this->assertIsString($query);
        $this->assertNotEmpty($query);
    }
}
