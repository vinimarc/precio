
<?php
use PHPUnit\Framework\TestCase;

class SystemTest extends TestCase {

    public function test_frontend_pages_exist() {
        $this->assertFileExists(__DIR__ . '/../../front-end/index.php');
        $this->assertFileExists(__DIR__ . '/../../front-end/home.php');
    }
}
