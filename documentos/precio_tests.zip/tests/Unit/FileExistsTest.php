
<?php
use PHPUnit\Framework\TestCase;

class FileExistsTest extends TestCase {

    public function test_backend_files_exist() {
        $this->assertFileExists(__DIR__ . '/../../back-end/api.php');
        $this->assertFileExists(__DIR__ . '/../../back-end/includes/auth.php');
        $this->assertFileExists(__DIR__ . '/../../back-end/includes/db.php');
    }
}
